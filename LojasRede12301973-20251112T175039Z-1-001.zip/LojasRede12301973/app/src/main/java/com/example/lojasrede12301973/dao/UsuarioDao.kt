// app/src/main/java/com.cotemig.lojasrede12301973.dao/UsuarioDao.kt
package com.cotemig.lojasrede12301973.dao // <<--- VERIFIQUE SE O SEU PACOTE ESTÁ CORRETO AQUI

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.cotemig.lojasrede12301973.model.Usuario // <<--- IMPORTANTE: Importe a classe Usuario
import kotlinx.coroutines.flow.Flow

@Dao // Anotação que indica que esta é uma interface DAO para o Room
interface UsuarioDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE) // Método para inserir ou substituir um usuário
    suspend fun insert(usuario: Usuario)

    @Update // Método para atualizar um usuário existente
    suspend fun update(usuario: Usuario)

    @Delete // Método para deletar um usuário
    suspend fun delete(usuario: Usuario)

    @Query("SELECT * FROM usuarios WHERE id = :id") // Consulta para buscar usuário por ID
    suspend fun getUsuarioById(id: Long): Usuario?

    @Query("SELECT * FROM usuarios WHERE email = :email AND senha = :senha") // Consulta para login
    suspend fun getUsuarioByEmailAndSenha(email: String, senha: String): Usuario?

    @Query("SELECT * FROM usuarios") // Consulta para obter todos os usuários (Flow para observação de mudanças)
    fun getAllUsuarios(): Flow<List<Usuario>>
}