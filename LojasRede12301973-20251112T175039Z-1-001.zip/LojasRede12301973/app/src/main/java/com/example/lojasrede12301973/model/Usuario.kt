// app/src/main/java/com.cotemig.lojasrede12301973.model/Usuario.kt
package com.cotemig.lojasrede12301973.model // <<--- VERIFIQUE SE O SEU PACOTE ESTÁ CORRETO AQUI

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "usuarios") // Define o nome da tabela no banco de dados
data class Usuario(
    @PrimaryKey(autoGenerate = true) // id será a chave primária e auto-gerada
    val id: Long = 0L,

    @ColumnInfo(name = "nome") // Nome da coluna para o nome do usuário
    val nome: String,

    @ColumnInfo(name = "email") // Nome da coluna para o email
    val email: String,

    @ColumnInfo(name = "senha") // Nome da coluna para a senha
    val senha: String
)