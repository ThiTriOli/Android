package com.example.lojasrede12301973.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.cotemig.lojasrede12301973.model.Usuario
import com.cotemig.lojasrede12301973.dao.UsuarioDao as UsuarioDao1

@Database(entities = [Usuario::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun usuarioDao(): UsuarioDao1

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "lojasrede_database" // Nome do seu banco de dados
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}