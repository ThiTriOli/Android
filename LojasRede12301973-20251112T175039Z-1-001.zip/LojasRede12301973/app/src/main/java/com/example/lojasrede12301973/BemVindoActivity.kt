package com.example.lojasrede12301973 // CORRIGIDO PARA O PACOTE CERTO

import com.example.lojasrede12301973.databinding.ActivityBemVindoBinding // CORRIGIDO O IMPORT
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class BemVindoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBemVindoBinding // Declaração para View Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBemVindoBinding.inflate(layoutInflater) // Inicializa o View Binding
        setContentView(binding.root)

        binding.logoutButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            // Estas flags limpam a pilha de atividades, impedindo o retorno à BemVindoActivity
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish() // Finaliza BemVindoActivity
        }
    }
}