package com.example.lojasrede12301973 // PACOTE CORRETO

import com.example.lojasrede12301973.databinding.ActivityMainBinding // CORRIGIDO O IMPORT
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.cotemig.lojasrede12301973.model.Usuario // <--- ADICIONE ESTA LINHA
// Os imports abaixo devem ser do SEU pacote principal
import com.example.lojasrede12301973.BemVindoActivity
import com.example.lojasrede12301973.CadastroActivity
import com.example.lojasrede12301973.database.AppDatabase
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var database: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = AppDatabase.getDatabase(applicationContext)

        // --- TEMPORÁRIO: POPULAR O BANCO DE DADOS COM UM CLIENTE PARA TESTE (REMOVA OU COMENTE DEPOIS) ---
        lifecycleScope.launch {
            val testUserEmail = "teste@cotemig.com"
            val testUserPassword = "123"
            val existingTestUser = database.usuarioDao().getUsuarioByEmailAndSenha(testUserEmail, testUserPassword)
            if (existingTestUser == null) {
                val newUser = Usuario(nome = "Cliente Teste", email = testUserEmail, senha = testUserPassword)
                database.usuarioDao().insert(newUser)
                Log.d("MainActivity", "Cliente de teste inserido: $testUserEmail")
            } else {
                Log.d("MainActivity", "Cliente de teste já existe: $testUserEmail")
            }
        }
        // --- FIM DO CÓDIGO TEMPORÁRIO ---


        binding.loginButton.setOnClickListener {
            val email = binding.emailEditText.text.toString()
            val senha = binding.passwordEditText.text.toString()

            if (email.isNotBlank() && senha.isNotBlank()) {
                lifecycleScope.launch {
                    val usuario = database.usuarioDao().getUsuarioByEmailAndSenha(email, senha)
                    if (usuario != null) {
                        Toast.makeText(this@MainActivity, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@MainActivity, BemVindoActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(this@MainActivity, "Email ou senha inválidos.", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(this@MainActivity, "Por favor, preencha email e senha.", Toast.LENGTH_SHORT).show()
            }
        }

        binding.registerButton.setOnClickListener {
            val intent = Intent(this, CadastroActivity::class.java)
            startActivity(intent)
        }
    }
}