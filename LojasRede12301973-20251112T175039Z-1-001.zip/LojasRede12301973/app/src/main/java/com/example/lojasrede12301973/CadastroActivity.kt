package com.example.lojasrede12301973 // CORRIGIDO PARA O PACOTE CERTO

import com.example.lojasrede12301973.databinding.ActivityCadastroBinding // CORRIGIDO O IMPORT
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.cotemig.lojasrede12301973.model.Usuario
import com.example.lojasrede12301973.database.AppDatabase
import kotlinx.coroutines.launch

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding // Declaração para View Binding
    private lateinit var database: AppDatabase // Declaração para o banco de dados

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroBinding.inflate(layoutInflater) // Inicializa o View Binding
        setContentView(binding.root)

        database = AppDatabase.getDatabase(applicationContext) // Obtém a instância do banco de dados

        binding.registerUserButton.setOnClickListener {
            val nome = binding.nameEditText.text.toString()
            val email = binding.emailRegisterEditText.text.toString()
            val senha = binding.passwordRegisterEditText.text.toString()

            if (nome.isNotBlank() && email.isNotBlank() && senha.isNotBlank()) {
                lifecycleScope.launch { // Usa corrotina para operação no banco de dados (assíncrona)
                    val newUsuario = Usuario(nome = nome, email = email, senha = senha)
                    database.usuarioDao().insert(newUsuario) // Insere o novo usuário
                    Toast.makeText(this@CadastroActivity, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
                    finish() // Retorna para a tela anterior (MainActivity) após o cadastro
                }
            } else {
                Toast.makeText(this@CadastroActivity, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}