plugins {
    id("com.android.application") // Sintaxe Kotlin DSL
    id("org.jetbrains.kotlin.android") // Sintaxe Kotlin DSL
    id("kotlin-kapt") // Sintaxe Kotlin DSL para Room e outros processadores
}

android {
    namespace = "com.example.lojasrede12301973"
    compileSdk = 35
    // Propriedade com ' = ' e aspas duplas
    // Propriedade com ' = '

    defaultConfig {
        applicationId = "com.example.lojasrede12301973" // Propriedade com ' = '
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false // Propriedade booleana com 'is' e ' = '
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8 // Propriedade com ' = '
        targetCompatibility = JavaVersion.VERSION_1_8 // Propriedade com ' = '
    }
    kotlinOptions {
        jvmTarget = "1.8" // Propriedade com ' = ' e aspas duplas
    }

    buildFeatures {
        viewBinding = true // Propriedade booleana com ' = '
    }
}

dependencies {
    // Dependências no Kotlin DSL usam parênteses para a chamada da função 'implementation' etc.
    // e aspas duplas para as strings.
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Dependências do Room
    implementation("androidx.room:room-runtime:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")

    // Dependências de Coroutines para escopos de ciclo de vida
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.3")

    // Dependências de teste
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}