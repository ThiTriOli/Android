package com.example.supermercado12301973.repositories.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.supermercado12301973.model.SupermercadoModel

@Dao
interface SupermercadoDao {
    @Insert
    fun insertProduto(produto: SupermercadoModel): Long
    @Update
    fun updateProduto(produto: SupermercadoModel): Int
    @Delete
    fun deleteProduto(produto: SupermercadoModel): Int
    @Query("SELECT * FROM Produto WHERE id_produto = :id")
    fun get(id: Int): SupermercadoModel
    @Query("SELECT * FROM Produto")
    fun getAll(): List<SupermercadoModel>
}