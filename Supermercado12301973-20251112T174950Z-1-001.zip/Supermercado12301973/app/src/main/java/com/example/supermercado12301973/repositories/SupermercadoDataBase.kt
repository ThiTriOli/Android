package com.example.supermercado12301973.repositories

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.supermercado12301973.model.SupermercadoModel
import com.example.supermercado12301973.repositories.dao.SupermercadoDao


@Database(entities = [SupermercadoModel::class], version = 3)
abstract class SupermercadoDataBase : RoomDatabase() {

    abstract fun supermercadoDAO(): SupermercadoDao

    companion object{
        @Volatile
        private lateinit var INSTANCE: SupermercadoDataBase

        fun getDataBase(context: Context): SupermercadoDataBase{
            if(!::INSTANCE.isInitialized) {
                synchronized(SupermercadoDataBase::class.java) {
                    if(!::INSTANCE.isInitialized) {
                        INSTANCE =
                            Room.databaseBuilder(context.applicationContext,
                                SupermercadoDataBase::class.java,
                                "supermercadodb")
                                .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                                .allowMainThreadQueries()
                                .build()
                    }
                }
            }
            return INSTANCE
        }

        // Migration from version 1 to 2
        private val MIGRATION_1_2: Migration = object : Migration(1, 2){
            override fun migrate(database: SupportSQLiteDatabase) {
            }
        }

        // Migration from version 2 to 3
        private val MIGRATION_2_3: Migration = object : Migration(2, 3){
            override fun migrate(database: SupportSQLiteDatabase) {
            }
        }
    }
}
