package com.example.supermercado12301973

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.supermercado12301540.R
import com.example.supermercado12301973.model.SupermercadoModel
import com.example.supermercado12301973.repositories.SupermercadoDataBase
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var eDTNome: EditText
    private lateinit var eDTPreco: EditText
    private lateinit var eDTQuant: EditText
    private lateinit var eDTDesc: EditText
    private lateinit var bTNCadastrar: Button

    private lateinit var database: SupermercadoDataBase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        database = SupermercadoDataBase.getDataBase(applicationContext)

        eDTNome = findViewById(R.id.EDT_Nome)
        eDTPreco = findViewById(R.id.EDT_Preco)
        eDTQuant = findViewById(R.id.EDT_Quantidade)
        eDTDesc = findViewById(R.id.EDT_Descricao)
        bTNCadastrar = findViewById(R.id.BTN_Cadastrar)

        bTNCadastrar.setOnClickListener{
            cadastrarUsuario()
        }
    }
    private fun cadastrarUsuario() {
        val nome = eDTNome.text.toString().trim()
        val preco = eDTPreco.text.toString().trim()
        val quant = eDTQuant.text.toString().trim()
        val desc = eDTDesc.text.toString().trim()

        if (nome.isEmpty() || preco.isEmpty() || quant.isEmpty() || desc.isEmpty()) {
            Toast.makeText(this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show()
            return
        }

        // Criar objeto Produto
        val produto = SupermercadoModel().apply {
            this.nome = nome
            this.preco = preco.toDouble()
            this.quantidade = quant.toInt()
            this.descricao = desc
        }

        // Inserir no banco de dados em uma corrotina
        lifecycleScope.launch {
            try {
                database.supermercadoDAO().insertProduto(produto)

                // Mostrar mensagem de sucesso
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Produto cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
                }

                // Passar para a próxima atividade
                val intent = Intent(this@MainActivity, DetalhesActivity::class.java).apply {
                    putExtra("NOME", nome)
                    putExtra("PRECO", preco)
                    putExtra("QUANTIDADE", quant)
                    putExtra("DESCRIÇÃO", desc)
                }
                startActivity(intent)

                eDTNome.text.clear()
                eDTPreco.text.clear()
                eDTQuant.text.clear()
                eDTDesc.text.clear()

            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Erro ao cadastrar produto: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}