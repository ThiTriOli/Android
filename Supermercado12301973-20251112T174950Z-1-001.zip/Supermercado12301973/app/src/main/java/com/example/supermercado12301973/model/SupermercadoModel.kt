package com.example.supermercado12301973.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Produto")
class SupermercadoModel {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id_produto")
    var id_produto: Int = 0

    @ColumnInfo(name = "nome")
    var nome: String = ""

    @ColumnInfo(name = "preco")
    var preco: Double = 0.0

    @ColumnInfo(name = "quantidade")
    var quantidade: Int = 0

    @ColumnInfo(name = "descricão")
    var descricao: String = ""
}