package com.example.supermercado12301973

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DetalhesActivity : AppCompatActivity() {
    private lateinit var tVNome: TextView
    private lateinit var tVPreco: TextView
    private lateinit var tVQuant: TextView
    private lateinit var tVDesc: TextView
    private lateinit var bTNVoltar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_detalhes)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        tVNome = findViewById(R.id.TV_Nome)
        tVPreco = findViewById(R.id.TV_Preco)
        tVQuant = findViewById(R.id.TV_Quantidade)
        tVDesc = findViewById(R.id.TV_Descricao)
        bTNVoltar = findViewById(R.id.BTN_Voltar)

        val nome = intent.getStringExtra("NOME")
        val preco = intent.getStringExtra("PRECO")
        val quant = intent.getStringExtra("QUANTIDADE")
        val desc = intent.getStringExtra("DESCRIÇÃO")

        tVNome.text ="Nome: $nome"
        tVPreco.text = "Preço: $preco"
        tVQuant.text = "Quantidade: $quant"
        tVDesc.text = "Descrição: $desc"

        bTNVoltar.setOnClickListener {
            this.onBackPressed()
        }
    }
}