package com.example.produtomaisbarato12301973

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Componentes da interface
        val btnComparar: MaterialButton = findViewById(R.id.btnComparar)
        val etProduto1: TextInputEditText = findViewById(R.id.etProduto1)
        val etProduto2: TextInputEditText = findViewById(R.id.etProduto2)
        val etProduto3: TextInputEditText = findViewById(R.id.etProduto3)
        val tvResultado: TextView = findViewById(R.id.tvResultado)

        btnComparar.setOnClickListener {
            try {
                // Validar campos
                if (etProduto1.text.isNullOrEmpty() || etProduto2.text.isNullOrEmpty() || etProduto3.text.isNullOrEmpty()) {
                    showToast("Preencha todos os preços")
                    return@setOnClickListener
                }

                // Obter valores
                val preco1 = etProduto1.text.toString().toDouble().also {
                    if (it <= 0) {
                        showToast("Preço 1 deve ser positivo")
                        return@setOnClickListener
                    }
                }

                val preco2 = etProduto2.text.toString().toDouble().also {
                    if (it <= 0) {
                        showToast("Preço 2 deve ser positivo")
                        return@setOnClickListener
                    }
                }

                val preco3 = etProduto3.text.toString().toDouble().also {
                    if (it <= 0) {
                        showToast("Preço 3 deve ser positivo")
                        return@setOnClickListener
                    }
                }

                // Determinar o produto mais barato
                val (mensagem, menorPreco) = when {
                    preco1 <= preco2 && preco1 <= preco3 -> Pair("Produto 1", preco1)
                    preco2 <= preco1 && preco2 <= preco3 -> Pair("Produto 2", preco2)
                    else -> Pair("Produto 3", preco3)
                }

                // Formatador de moeda
                val formatador = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

                // Exibir resultado
                tvResultado.text = "Você deve comprar o $mensagem\nPreço: ${formatador.format(menorPreco)}"
                tvResultado.visibility = View.VISIBLE

            } catch (e: NumberFormatException) {
                showToast("Digite valores numéricos válidos")
            }
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}