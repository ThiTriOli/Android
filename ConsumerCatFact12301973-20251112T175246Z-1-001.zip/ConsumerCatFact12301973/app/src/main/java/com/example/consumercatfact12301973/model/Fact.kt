package com.example.consumercatfact12301973.model

data class Fact(
    val fact: String,
    val length: Int
)