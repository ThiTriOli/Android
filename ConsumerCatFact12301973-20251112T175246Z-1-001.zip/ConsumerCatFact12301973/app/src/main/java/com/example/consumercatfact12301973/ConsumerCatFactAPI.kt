package com.example.consumercatfact12301973

import com.example.consumercatfact12301973.model.Fact
import retrofit2.Response
import retrofit2.http.GET

interface ConsumerCatFactAPI {
    @GET("/fact")
    suspend fun getFact(): Response<Fact>
}