package com.example.consumercatfact12301973

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.consumercatfact12301973.model.Fact
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ResultadoActivity : AppCompatActivity() {
    private lateinit var factTextView: TextView
    private lateinit var lengthTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_resultado)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        factTextView = findViewById(R.id.TV_Fato)
        lengthTextView = findViewById(R.id.TV_Length)
        fetchCatFact()
    }

    private fun fetchCatFact() {
        val consumerCatFactAPI = RetroFitHelper.getInstance().create(ConsumerCatFactAPI::class.java)
        GlobalScope.launch(Dispatchers.IO) {
            try {
                val response = consumerCatFactAPI.getFact()

                withContext(Dispatchers.Main) {
                    if (response.isSuccessful && response.body() != null) {
                        val fact: Fact = response.body()!!
                        factTextView.text = "Fact: ${fact.fact}"
                        lengthTextView.text = "Length: ${fact.length}"
                        Log.d("ResultadoActivity", "Fact fetched: ${fact.fact}")
                    } else {
                        Log.e("ResultadoActivity", "Error: ${response.code()} ${response.message()}")
                        Toast.makeText(this@ResultadoActivity, "Failed to fetch fact: ${response.code()}", Toast.LENGTH_LONG).show()
                        factTextView.text = "Error fetching fact."
                        lengthTextView.text = ""
                    }
                }
            } catch (e: Exception) {
                Log.e("ResultadoActivity", "Network Exception: ${e.message}")
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@ResultadoActivity, "Network error: Check connection", Toast.LENGTH_LONG).show()
                    factTextView.text = "Network error."
                    lengthTextView.text = ""
                }
            }
        }
    }
}