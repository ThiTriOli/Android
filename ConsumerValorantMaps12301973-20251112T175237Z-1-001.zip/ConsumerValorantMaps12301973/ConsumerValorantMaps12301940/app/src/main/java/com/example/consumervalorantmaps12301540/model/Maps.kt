package com.example.consumervalorantmaps12301540.model

data class Maps(
    val status: Int,
    val data: DataData
)

data class DataData(
    val uuid: String,
    val displayName: String,
    val narrativeDescription: String?,
    val tacticalDescription: String,
    val coordinates: String,
    val displayIcon: String,
    val listViewIcon: String,
    val listViewIconTall: String,
    val splash: String,
    val stylizedBackgroundImage: String,
    val premierBackgroundImage: String,
    val assetPath: String,
    val mapUrl: String,
    val xMultiplier: Float,
    val yMultiplier: Float,
    val xScalarToAdd: Float,
    val yScalarToAdd: Float,
    val callouts: List<CalloutsData>
)

data class CalloutsData(
    val regionName: String,
    val superRegion: String,
    val superRegionName: String,
    val location: LocationData,
    val scale3D: LocationData?,
    val rotation: LocationData?
)

data class LocationData(
    val x: Float,
    val y: Float,
    val z: Float
)
