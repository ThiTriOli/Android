package com.example.consumervalorantmaps12301540

import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ResultadoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_resultado)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val displayNameTV = findViewById<TextView>(R.id.displayNameTV)
        val descriptionTV = findViewById<TextView>(R.id.TacticalDescriptionTV)
        val splash = findViewById<ImageView>(R.id.splash)

        val mapsUUID = intent.getStringExtra("UUID_EXTRA")

        if (mapsUUID != null) {
            val valorantMapsAPI = RetroFitHelper.getInstance().create(ValorantMapsAPI::class.java)
            GlobalScope.launch (Dispatchers.IO){
                try {
                    val response = valorantMapsAPI.getMaps(mapsUUID)
                    if (response.isSuccessful){
                        val valorantResponse = response.body()
                        val itemsData = valorantResponse?.data
                        Log.d("Retorno API: ", itemsData.toString())
                        withContext(Dispatchers.Main){
                            displayNameTV.text = itemsData?.displayName
                            descriptionTV.text = itemsData?.tacticalDescription

                            itemsData?.splash?.let { imageUrl ->
                                Glide.with(this@ResultadoActivity)
                                    .load(imageUrl)
                                    .into(splash)
                            }
                        }
                    } else{
                        withContext(Dispatchers.Main){
                            displayNameTV.text = "Erro: ${response.code()}"
                            descriptionTV.text = "Falha ao carregar os dados."
                        }
                    }
                } catch (e: Exception){
                    withContext(Dispatchers.Main){
                        displayNameTV.text = "Erro de conexão: ${e.message}"
                        descriptionTV.text = "Verifique sua conexão com a internet."
                    }
                }
            }
        }
    }
}