package com.example.consumervalorantmaps12301540

import com.example.consumervalorantmaps12301540.model.Maps
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface ValorantMapsAPI {
    @GET("maps/{mapsUuid}")
    suspend fun getMaps(@Path("mapsUuid") mapsUuid: String): Response<Maps>
}