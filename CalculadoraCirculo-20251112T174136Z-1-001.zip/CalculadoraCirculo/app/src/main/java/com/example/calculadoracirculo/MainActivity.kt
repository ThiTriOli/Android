package com.example.calculadoracirculo

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val etRaio = findViewById<EditText>(R.id.edt_area)
        val btnEnviar = findViewById<Button>(R.id.btn_enviar)
        val tvResu = findViewById<TextView>(R.id.tv_resu)

        btnEnviar.setOnClickListener {
            val raioString = etRaio.text.toString() // Captura o valor dentro do listener

            if (raioString.isNotEmpty()) {
                val raio = raioString.toDouble() // Converte a string para Double
                tvResu.text = "Área = ${raio * raio * 3.14}"
            } else {
                tvResu.text = "Por favor, insira um valor para o raio."
            }
        }
    }
}