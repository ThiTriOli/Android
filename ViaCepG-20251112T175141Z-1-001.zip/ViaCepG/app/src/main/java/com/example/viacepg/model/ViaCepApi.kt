package com.example.viacepg.model

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface ViaCepApi {
    @GET("ws/{cep}/json")
    suspend fun getEnderecos(@Path("cep") cep: String) : Response<Endereco>

}