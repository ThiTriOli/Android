package com.example.viacepg

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.viacepg.model.ViaCepApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ResultadoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_resultado)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val cepTextView = findViewById<TextView>(R.id.cepTv)
        val bairroTextView = findViewById<TextView>(R.id.bairroTv)
        val cidadeTextView = findViewById<TextView>(R.id.cidadeTv)
        val estadoTextView = findViewById<TextView>(R.id.estadoTv)

        val cep = intent.getStringExtra("CEP_EXTRA")
        
        if (cep != null) {

            val viaCepApi = RetrofitHelper.getInstace().create(ViaCepApi::class.java)

            GlobalScope.launch (Dispatchers.IO){
                try {
                    val response = viaCepApi.getEnderecos(cep)
                    if ( response.isSuccessful){
                        val endereco = response.body()

                        Log.d("RETORNO", endereco.toString())

                        withContext(Dispatchers.Main){
                            cepTextView.text = endereco?.cep
                            bairroTextView.text = endereco?.bairro
                            cidadeTextView.text = endereco?.localidade
                            estadoTextView.text = endereco?.estado

                        }
                    }
                    else{
                        withContext(Dispatchers.Main){
                           cepTextView.text = "Erro: ${response.code()}"
                        }
                    }
                }catch (e: Exception){
                    withContext(Dispatchers.Main) {
                        cepTextView.text = "Ocorreu um erro ${e.message}"
                    }
                }
            }

        }
        else{
            cepTextView.text = "CEP não informado/não encontrado..."
        }
    }
}