import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.saudeja12301973.R
import java.util.Locale

class MainActivity : AppCompatActivity() {

    // Lista de medicamentos disponíveis (em minúsculas para comparação)
    private val medicamentosDisponiveis = listOf(
        "paracetamol",
        "ibuprofeno",
        "amoxicilina",
        "dorflex",
        "loratadina",
        "omeprazol",
        "dipirona",
        "soro fisiológico"
    )

    private lateinit var etMedicamento: EditText
    private lateinit var btnConsultar: Button
    private lateinit var tvNomeMedicamento: TextView
    private lateinit var tvResultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializar componentes
        etMedicamento = findViewById(R.id.etMedicamento)
        btnConsultar = findViewById(R.id.btnConsultar)
        tvNomeMedicamento = findViewById(R.id.tvNomeMedicamento)
        tvResultado = findViewById(R.id.tvResultado)

        // Configurar clique do botão
        btnConsultar.setOnClickListener {
            consultarMedicamento()
        }
    }

    private fun consultarMedicamento() {
        val input = etMedicamento.text.toString().trim()

        if (input.isEmpty()) {
            Toast.makeText(this, "Digite o nome de um medicamento", Toast.LENGTH_SHORT).show()
            return
        }

        // Formatar o nome (primeira letra maiúscula)
        val nomeFormatado = input.lowercase(Locale.getDefault())
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }

        // Verificar disponibilidade
        val disponivel = medicamentosDisponiveis.contains(input.lowercase(Locale.getDefault()))

        // Exibir resultados
        tvNomeMedicamento.text = nomeFormatado
        tvResultado.text = if (disponivel) {
            "$nomeFormatado está disponível em estoque."
        } else {
            "$nomeFormatado não está disponível no momento."
        }

        // Tornar visíveis os TextViews de resultado
        tvNomeMedicamento.visibility = View.VISIBLE
        tvResultado.visibility = View.VISIBLE
    }
}